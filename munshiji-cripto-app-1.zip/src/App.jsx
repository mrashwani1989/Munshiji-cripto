import React from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { Coins, Newspaper } from "lucide-react";

const demoData = [
  { name: "Jun 1", value: 10000 },
  { name: "Jun 5", value: 10250 },
  { name: "Jun 10", value: 9950 },
  { name: "Jun 15", value: 10350 },
];

export default function App() {
  return (
    <div className="p-4 grid gap-4 grid-cols-1 md:grid-cols-2">
      <div className="shadow-xl rounded-2xl p-4 border">
        <h2 className="text-xl font-bold mb-2 flex items-center gap-2"><Coins className="w-5 h-5" /> आपका पोर्टफोलियो</h2>
        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={demoData}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="value" stroke="#10b981" strokeWidth={2} />
          </LineChart>
        </ResponsiveContainer>
        <p className="mt-4 text-sm">कुल निवेश: ₹10,000 | लाभ: ₹350</p>
      </div>
      <div className="shadow-xl rounded-2xl p-4 border">
        <h2 className="text-xl font-bold mb-2 flex items-center gap-2"><Newspaper className="w-5 h-5" /> ताज़ा क्रिप्टो न्यूज़</h2>
        <ul className="list-disc pl-5 text-sm">
          <li>Bitcoin ETF पर बड़ी घोषणा</li>
          <li>Ethereum 2.0 टेस्टनेट लाइव</li>
        </ul>
      </div>
    </div>
  );
}